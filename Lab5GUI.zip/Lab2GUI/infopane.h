#ifndef INFOPANE_H
#define INFOPANE_H

//My idea is to use "panes" as the pages of a "book"
//each new entry would be another pane with new information
//I haven't taken the Databases class so I don't know a lot\
//about efficient ways to store data but this is just a prototype.
class InfoPane
{
public:
    InfoPane();
    void TakePicture(); //takes a picture with back-facing cam and saves to pane.
    void Reschedule(char * treatment); //some way to have a tree trimming
                                      //or pesticide scheduled off-sched.
    void ReadNFC(/*some NFC address*/); //I need to do more research on this.
    void TreatNow(); //one-click scheduler for pesticides
    void TrimNow(); //one-click scheduler for trimming(windstorms, car accidents, earthquakes).

private:
    int m_id; //identification # of plant. Superimposed on image of plant.
    int m_age; //age of the plant/tree
    //some way to store a calender date,
    //would like to use the built-in
    //calenders from smartphones.
    //Several dates need to be stored:
    //  m_planted_on;
    //  m_fed_on;
    //  m_pest_on;
    //
    //Each tree has a picture, so save it somehow.
    char * m_name; //user-input name
    char * m_type; //for drop down menu: Plant type.
    char * m_treatment; //what pesticide the tree is using.
    char * m_address; //closest address to the tree/plant.
    //The most important piece of info is NFC address stored on the tag of the tree.
};
#endif // INFOPANE_H
