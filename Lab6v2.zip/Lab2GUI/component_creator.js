var component;

function createInfoPaneObject() {

    component = Qt.createComponent("infoPane.qml");

    if (component.status === Component.Ready || component.status === Component.Error)
        finishCreation();

    else
        component.statusChanged.connect(finishCreation);
    }

function finishCreation() {

    if (component.status === Component.Ready)
    {
        var infoPane = component.createObject(root, {"x": 100, "y": 100});

        if (infoPane == null)
            console.log("Error creating image");
    }
    else if (component.status === Component.Error)
        console.log("Error loading component:", component.errorString());
}
