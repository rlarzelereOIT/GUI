#ifndef INFOPANE_H
#define INFOPANE_H
#inlude <ctime.h>
#include <string>

//My idea is to use "panes" as the pages of a "book"
//each new entry would be another pane with new information
//I haven't taken the Databases class so I don't know a lot\
//about efficient ways to store data but this is just a prototype.
class InfoPane : public QOBJECT
{
    Q_OBJECT

    Q_PROPERTY(int m_id READ GetID WRITE SetID NOTIFY idChanged)
    Q_PROPERTY(int m_age READ GetAge WRITE SetAge NOTIFY ageChanged)
    Q_PROPERTY(QString m_name READ GetName WRITE SetName NOTIFY nameChanged)
    Q_PROPERTY(PlantType m_type READ GetType WRITE SetType NOTIFY typeChanged)
    Q_PROPERTY(TreatType m_treatment READ GetTreat WRITE SetTreat NOTIFY treatChanged)
    Q_PROPERTY(QString m_address READ GetAddress WRITE SetAddress NOTIFY addressChanged)
    Q_PROPERTY(QString m_email READ GetEmail WRITE SetEmail NOTIFY emailChanged)
    Q_PROPERTY(int m_sprinkler READ GetSprinkler WRITE SetSprinkler NOTIFY sprinklerChanged)

    Q_ENUMS(PlantType)
    Q_ENUMS(TreatType)
public:
    InfoPane(QObject * parent);]
    ~InfoPane();
    enum PlantType {Tree, Flower, Bush, Herb};
    enum TreatType {Fertilizer, Pesticide, Ethephon, Naphthatic_Acid};
    void TakePicture(); //takes a picture with back-facing cam and saves to pane.
    void Reschedule(TreatType treatment);   //some way to have a tree trimming
                                            //or pesticide scheduled off-sched.
    //void ReadNFC(/*some NFC address*/);   //I need to do more research on this.

    void TreatNow(); //one-click scheduler for pesticides
    void TrimNow(); //one-click scheduler for trimming(windstorms, car accidents, earthquakes).

    int GetID();
    int GetAge();
    QString GetName();
    PlantType GetType();
    TreatType GetTreat();
    QString GetAddress();
    QString GetEmail();
    int GetSprinkler();

public slots:
    void SetID(int ID);
    void SetAge(int age);
    void SetName(QString& name);
    void SetType(PlantType type);
    void SetTreat(TreatType treatment);
    void SetAddress(QString& address);
    void SetEmail(QString& email);
    void SetSprinkler(int sprinkler);

signals:
    void idChanged(int ID);
    void ageChanges(int age);
    void nameChanged(QString & name);
    void typeChanged(PlantType type);
    void treatChanged(TreatType treatment);
    void addressChanged(QString& address);
    void emailChanged(QString& email);
    void sprinklerChanged(int sprinkler);

private:
    int m_id;               //identification # of plant. Superimposed on image of plant.
    int m_age;              //age of the plant/tree
    QString m_name;         //user-input name
    PlantType m_type;       //for drop down menu: Plant type.
    TreatType m_treatment;  //what pesticide the tree is using.
    QString m_address;      //closest address to the tree/plant.
    QString m_email;        //email address of notifications
    int m_sprinkler;
    //some way to store a calender date,
    //would like to use the built-in
    //calenders from smartphones.
    //Several dates need to be stored:
    //  m_planted_on;
    //  m_fed_on;
    //  m_pest_on;
    //
    //Each tree has a picture, so save it somehow.
    //The most important piece of info is NFC address stored on the tag of the tree.
};
#endif // INFOPANE_H
