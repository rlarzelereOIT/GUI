#include "infopane.h"

InfoPane::InfoPane(QObject * parent):m_id(0),m_age(0),m_name("unknown"),m_type(0),
    m_treatment(0),m_address("unknown"),m_email("unknwon"),m_sprinkler(0)
{

}
InfoPane::~InfoPane()
{

}

int InfoPane::GetID()
{
    reutrn m_id;
}
void InfoPane::SetID(int ID)
{
    m_id = ID;
}

int InfoPane::GetAge()
{
    return m_age;
}
void InfoPane::SetAge(int age)
{
    m_age = age;
}

QString InfoPane::GetName()
{
    return m_name;
}
void InfoPane::SetName(QString& name)
{
    m_name = name;
}

PlantType InfoPane::GetType()
{
    return m_type;
}
void InfoPane::SetType(PlantType type)
{
    m_type = type;
}

TreatType InfoPane::GetTreat()
{
    return m_treatment;
}
void InfoPane::SetTreat(TreatType treatment)
{
    m_treatment = treatment;
}

QString InfoPane::GetAddress()
{
    return m_address;
}
void InfoPane::SetAddress(QString& address)
{
    m_address = address;
}

QString InfoPane::GetEmail()
{
    reutrn m_email;
}
void InfoPane::SetEmail(QString& email)
{
    m_email = email;
}

int InfoPane::GetSprinkler()
{
    return m_sprinkler;
}
void InfoPane::SetSprinkler(int sprinkler)
{
    m_sprinkler = sprinkler;
}
