#include "splashscreen.h"

splashScreen::splashScreen(QObject *parent)
    : QAbstractItemModel(parent)
{
}

QVariant splashScreen::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

QModelIndex splashScreen::index(int row, int column, const QModelIndex &parent) const
{
    // FIXME: Implement me!
}

QModelIndex splashScreen::parent(const QModelIndex &index) const
{
    // FIXME: Implement me!
}

int splashScreen::rowCount(const QModelIndex &parent) const
{
    if (!parent.isValid())
        return 0;

    // FIXME: Implement me!
}

int splashScreen::columnCount(const QModelIndex &parent) const
{
    if (!parent.isValid())
        return 0;

    // FIXME: Implement me!
}

QVariant splashScreen::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    // FIXME: Implement me!
    return QVariant();
}
